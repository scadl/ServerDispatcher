#!/bin/bash
/usr/bin/php sd_server.php